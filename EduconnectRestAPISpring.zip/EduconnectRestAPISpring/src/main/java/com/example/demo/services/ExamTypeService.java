package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.ExamType;
import com.example.demo.repositories.ExamTypeRepository;

@Service
public class ExamTypeService {
	@Autowired
	ExamTypeRepository examrepo;
	
	public List<ExamType> getExamTypes()
	{
		return examrepo.findAll();
	}
	
	public ExamType getById(int id)
	{
		return examrepo.findById(id).get();
	}
}
