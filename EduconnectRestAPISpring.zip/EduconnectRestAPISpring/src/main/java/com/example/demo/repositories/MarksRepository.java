package com.example.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.AcademicYear;
import com.example.demo.entities.ExamType;
import com.example.demo.entities.Marks;
import com.example.demo.entities.Standard;
import com.example.demo.entities.Student;
import com.example.demo.entities.Subject;


@EnableJpaRepositories
@Repository
public interface MarksRepository extends JpaRepository<Marks, Integer> {

	@Query("SELECT m FROM Marks m WHERE m.yid.yid = :yid AND m.stud_id .sid= :studid AND m.type_id.typeid = :typeid AND m.std_id.std_id=:stdid")
	public List<Marks> viewMarksbyStudent(int yid,int studid, int typeid,int stdid);
	
	@Query("SELECT m FROM Marks m WHERE m.yid.yid = :yid AND m.tid.uid = :tid  AND m.type_id.typeid = :typeid AND m.std_id.std_id=:stdid AND m.sub_id.sub_id=:subid")
	public List<Marks> viewMarksbyTeacher(int yid, int typeid,int stdid,int tid,int subid);
}
