package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.AcademicYear;
import com.example.demo.entities.ExamType;
import com.example.demo.entities.Marks;
import com.example.demo.entities.Standard;
import com.example.demo.entities.Student;
import com.example.demo.entities.Subject;
import com.example.demo.repositories.MarksRepository;

@Service
public class MarksService {

    @Autowired
    private MarksRepository mrepo;
    
    public Marks saveMarks(Marks mark) {
        return mrepo.save(mark);
    }

    public List<Marks> getAllMarks()
    {
    	return mrepo.findAll();
    }
    public List<Marks> viewMarksbystudent(int yid,int studid,int typeid,int stdid) {
        return mrepo.viewMarksbyStudent(yid, studid, typeid,stdid);
    }
    
    public List<Marks> viewMarksbyTeacher(int yid,int typeid,int stdid,int tid,int subid) {
        return mrepo.viewMarksbyTeacher(yid, typeid,stdid,tid,subid);
    }
}
