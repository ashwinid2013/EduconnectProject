package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.AcademicYear;
import com.example.demo.entities.SubTeacher;
import com.example.demo.repositories.SubTeacherRepository;

@Service
public class SubTeacherService {

	@Autowired
	SubTeacherRepository strepo;
	
	 public SubTeacher save(SubTeacher st)
	 {
		return strepo.save(st);
	 }
	 
	 public List<SubTeacher> getSubTeachers()
	 {
		 return strepo.findAll();
	 }
	 
	 public List<SubTeacher> getClassTeachersByStandard(int stdid)
	 {
		 return strepo.getClassTeachersByStandard(stdid);
	 }
	 
	 public List<SubTeacher> getClassTeachersByTeachersID(int tid)
	 {
		 return strepo.getClassTeachersByTeacherId(tid);
	 }
	 
	 public List<SubTeacher> getSubjectByStandardandTeachersId(int tid,int std)
	 {
		 return strepo.getSubjectsByTeacherandStandard(tid,std);
	 }
}
