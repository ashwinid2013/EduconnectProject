package com.example.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.SubTeacher;

@Repository
public interface SubTeacherRepository extends JpaRepository<SubTeacher, Integer>
{
		@Query("select s from SubTeacher s where s.std_id.std_id=:std")
		public List<SubTeacher> getClassTeachersByStandard(int std);
		
		@Query("select s from SubTeacher s where s.tid.uid=:tid")
		public List<SubTeacher> getClassTeachersByTeacherId(int tid);
		
		@Query("select s from SubTeacher s where s.tid.uid=:tid and s.std_id.std_id=:std")
		public List<SubTeacher> getSubjectsByTeacherandStandard(int tid,int std);
		
		
}
