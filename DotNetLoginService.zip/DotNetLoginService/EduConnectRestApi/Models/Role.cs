﻿using System;
using System.Collections.Generic;

namespace EduConnectRestApi.Models
{
    public partial class Role
    {
        public int Rid { get; set; }
        public string? RoleName { get; set; }
    }
}
